# myXLSX
Based on the <br>
    https://github.com/SheetJS <br>
    https://github.com/SheetJS/ssf <br>
     https://github.com/Stuk/jszip <br>
    
    see index.html
	
<b>ExcelToWordTemplate.zip</b>	
An example of filling out a MS Word Template with data from Excel<br><br>
Пример заполнения Шаблона MS Word данными из Excel
В документе Word обозначить поля для заполнения {field1}, {field2} <br>
В файле Excel в соответствующих колонках {field1}, {field2} поместить данные для заполнения.<br>
В первой колонке должны быть уникальные данные (т.к. они необходимы для именования заполненных файлов Word)<br><br>

Открыть в браузере index.html (можно без WEB сервера)


